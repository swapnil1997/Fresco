#!/bin/bash
str="Hello World"
echo $str
