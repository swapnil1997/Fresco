count=1
for ((c = 1 ; c <= 4 ; c++))
do
	let "count++"
done
echo $count
