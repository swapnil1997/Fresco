echo "Bash version ${BASH_VERSION}.."
for i in {0..10..2}
do
	echo "Welcome $i times"
done
